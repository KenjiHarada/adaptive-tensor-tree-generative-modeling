#!/bin/bash
python ../apply_att.py -o -b -D Results --data_dir Data -N 2000000 -i 1000 qmnist 5 3 0 0.01 10 10 1000 240102 240102
