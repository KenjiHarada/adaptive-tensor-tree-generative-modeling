#!/bin/bash
for i in {230700..230704}
do
    python make_data.py 128 10 $i
    python ../apply_att.py -N 5000 -D Results random 0 1 0 0.05 1 10 10 $i $i
    python ../apply_att.py -N 5000 -D Results random 0 3 0 0.05 1 10 10 $i $i
done

