import numpy as np
import argparse

parser = argparse.ArgumentParser(description="Generate data files")
parser.add_argument(
    "SIZE", type=int, nargs="?", default=128, help="SIZE: number of variables"
)
parser.add_argument(
    "NSAMPLE", type=int, nargs="?", default=10, help="NSAMPLE: number of samples"
)
parser.add_argument(
    "SEED", type=int, nargs="?", default=230700, help="SEED: random seed"
)

args = parser.parse_args()
rng = np.random.default_rng(args.SEED)
data = np.zeros((args.NSAMPLE, args.SIZE, 2), dtype=np.float32)
for i in range(args.NSAMPLE):
    x = rng.integers(2, size=args.SIZE)
    for j in range(args.SIZE):
        data[i, j, x[j]] = 1.0
        if j >= args.SIZE / 4 and j < args.SIZE * 3 / 4:
            data[i, j, 0] = 1.0
            data[i, j, 1] = 0
        if data[i, j, 0] + data[i, j, 1] != 1:
            print(i, j, data[i, j, 0], data[i, j, 1])
            raise ValueError("Invalid data")
BASE_ID = f"random"
data.tofile(f"{BASE_ID}_sample.dat")
data.tofile(f"{BASE_ID}_test.dat")
with open(f"{BASE_ID}.des", "w") as f:
    f.write(f"size={args.SIZE}\n")
    f.write(f"dtype=float32\n")
