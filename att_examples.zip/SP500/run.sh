#!/bin/bash
python ../apply_att.py -D Results --data_dir Data -N 200000 sp500h 5 3 0 0.001 10 5 1794 111104 111104
