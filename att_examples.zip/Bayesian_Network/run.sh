#!/bin/bash
for i in {111100..111104}
do
    python ../apply_att.py -b --data_dir Data -D Results -i 0 -N 5000 -I 10 chain 5 3 0 0.01 10 4 1000 111101 111101
    python ../apply_att.py -b --data_dir Data -D Results -i 0 -N 5000 -I 10 branch 5 3 0 0.01 10 4 1000 111101 111101
    python ../apply_att.py -b --data_dir Data -D Results -i 0 -N 5000 -I 10 collision 5 3 0 0.01 10 4 1000 111101 111101
done
